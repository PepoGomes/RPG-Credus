module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['i.imgur.com', 'media.discordapp.net']
  }
}